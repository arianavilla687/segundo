<?php

$nombre = $_POST['txt_nombre'];
$estrato = $_POST['estrato'];
$cantidad = $_POST['txt_number'];

$precio_almuerzo = 1500;

if  ($estrato>=='0' or $estrato=='1' or $estrato== '2')
{

    $total = $cantidad * $precio_almuerzo - 1500;
    echo "Usuario $nombre tu total a pagar es de =$$total",  "Recuerda que por ser de los estratos 0, 1 o 2, tu primer almuerzo sale gratis";
}
else {
   $total = $cantidad * $precio_almuerzo;

     echo "Usuario $nombre tu total a pagar es de =$$total";
}

?>

 



