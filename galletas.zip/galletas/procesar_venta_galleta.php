<?php

require "config/conex.php";

$valor = $_POST ["valor"];
$cantidad =$_POST ["cantidad"];
$total = $valor * $cantidad;
$disponibles = 100 - $cantidad;

if( $cantidad >100)
   exit ("No puedes realizar esta venta, superas el limite de productos");


 
$sql ="INSERT INTO vender (cantidad, valor, total) VALUES (".$valor.",".$cantidad.",".$total.")";

if($dbh->query($sql))
{
    
    echo "venta exitosa, vendiste $cantidad galletas, te quedan disponibles $disponibles galletas"; 
}else
{
    echo "Error de venta";
}