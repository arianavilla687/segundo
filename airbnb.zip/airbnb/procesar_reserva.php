<?php
//Paso 1
require "config/conex.php";

//Paso 2: capturar variables
$_habitacion = $_POST ["habitaciones"];

//Paso 3: armar el sql
$sql = "UPDATE habitaciones
SET
estado = 1
WHERE
id = ".$_habitacion." ";

//Paso 4: ejecutarel sql
if($dbh->query($sql))
{
    echo "Actualizacion correcta";
}else
{
    "Error actualizacion";
}
?>