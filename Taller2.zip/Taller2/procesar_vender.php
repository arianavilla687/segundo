<?php

require "config/conex.php";


$_valor = $_POST["valor"];
$_cantidad = $_POST["cantidad"];
$_total =  $_cantidad * $_valor;

$sql="INSERT INTO ventas(cantidad, valor, total) VALUES (".$_cantidad.",".$_valor.",".$_total.")";

if($dbh->query($sql))   
{
    $idVenta = $dbh->lastInsertId();
    echo "Venta exitosa. ID de la venta: " . $idVenta;
}else
{
    echo "Error de venta";
}