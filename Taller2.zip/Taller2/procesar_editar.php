<?php

require "config/conex.php";

$cod = $_POST["cod"];
$_valor = $_POST["valor"];
$_cantidad = $_POST["cantidad"];
$_total =  $_cantidad * $_valor;

$sql ="UPDATE ventas SET cantidad=$_cantidad, valor=$_valor, total=$_total where id=$cod";

if($dbh->query($sql))
{
    echo "Datos editados Correctamente";
}else{
    echo "Error de edicion";
}